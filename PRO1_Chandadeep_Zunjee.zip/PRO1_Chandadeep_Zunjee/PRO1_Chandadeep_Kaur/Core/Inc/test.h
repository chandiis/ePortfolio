/*
 * test.h
 *
 *  Created on: 17 Dec 2025
 *      Author: kaur_
 */

#ifndef INC_TEST_H_
#define INC_TEST_H_

void Test_program();
void test_shift_register();
void test_pedestrian_lights();
void test_trafficlight();
void test_switch_inputs();
void test_car_presence();

#endif /* INC_TEST_H_ */
