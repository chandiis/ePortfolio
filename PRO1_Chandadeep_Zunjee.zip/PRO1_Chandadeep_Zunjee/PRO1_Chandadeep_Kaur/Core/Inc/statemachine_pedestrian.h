/*
 * statemachine.h
 *
 *  Created on: 9 Dec 2025
 *      Author: kaur_
 */

#ifndef SRC_STATEMACHINE_H_
#define SRC_STATEMACHINE_H_
#include <stdint.h>
#include <stdbool.h>
#include "leds.h"

void PedestrianCrossing1(void);
void PedestrianCrossing2(void);


#endif /* SRC_STATEMACHINE_H_ */
