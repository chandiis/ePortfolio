/*
 * car_statemachine.h
 *
 *  Created on: 14 Dec 2025
 *      Author: kaur_
 */

#ifndef INC_CAR_STATEMACHINE_H_
#define INC_CAR_STATEMACHINE_H_
#include <stdint.h>
#include <stdbool.h>
#include "leds.h"

void RoadCrossing(void);

#endif /* INC_CAR_STATEMACHINE_H_ */
