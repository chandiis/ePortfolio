enemy new_enemy(int room, char* name, int hp, int damage, char* loot);
